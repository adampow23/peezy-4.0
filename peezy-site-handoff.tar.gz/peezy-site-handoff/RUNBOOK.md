# Peezy Website — Deployment Runbook for Claude Code
### Mission: take the finished site in `./peezy-site/` from this folder to live at peezymove.com.

You are executing, not designing. The site is already built and verified. Every decision has been made. Your job: verify → publish → deploy → clean up → prove it's live. Do not modify copy, design tokens, components, or page content. Do not add dependencies.

**Bounded retry rule:** any step that fails twice → STOP, report the exact error, wait for Adam. Never improvise around a failure.

**HALT points** are marked. At a HALT, print what you need from Adam and wait. Do not skip a HALT.

---

## Phase 0 — Preflight (no side effects)

1. Check tooling; print versions:
   - `node -v` (need ≥ 20), `npm -v`, `git --version`
   - `gh auth status` — GitHub CLI authenticated as adampow23
   - `npx vercel whoami` — Vercel authenticated
2. **HALT №1 — ask Adam for two values before doing anything else:**
   - The real App Store listing URL for Peezy (for `NEXT_PUBLIC_APP_STORE_URL`)
   - Confirmation to fully replace the contents of `adampow23/peezy-site` (git history is preserved; old files are removed)
   If `gh` or `vercel` are not authenticated, also ask Adam to run `gh auth login` / `npx vercel login` now.

## Phase 1 — Local verification (prove the handoff is intact)

```bash
cd peezy-site
npm install
npm run build
```
- Build must complete with all 13 routes static. Paste the route table into your report.
- Run the copy-integrity sweep; both must return nothing:
```bash
grep -rn -iE "real person|annual|/month|/week|\$49|free trial" app components lib --include="*.tsx" --include="*.ts"
grep -rn "noindex" app components lib --include="*.tsx" --include="*.ts" | grep -v "robots.ts"
```
- If the build fails: retry once after `rm -rf node_modules package-lock.json && npm install`. Second failure → STOP.

## Phase 2 — Publish to GitHub (preserve history, replace contents)

```bash
cd ..
gh repo clone adampow23/peezy-site repo-old
cd repo-old
git rm -rf . --quiet || true
cp -r ../peezy-site/. .
rm -rf node_modules .next
git add -A
git commit -m "Site v2: full rebuild — live-app launch site (Next 15, static, Allconnect-ready)"
git push origin HEAD
```
- Confirm the default branch now shows the new tree (`gh repo view --web` optional; `git log -1` in report).
- If the repo doesn't exist: `gh repo create adampow23/peezy-site --private --source ../peezy-site --push`.

## Phase 3 — Deploy to Vercel

From the repo directory:
```bash
npx vercel link        # scope: Adam's account; link to existing project if one exists, else create "peezy-site"
npx vercel env add NEXT_PUBLIC_APP_STORE_URL production   # paste the URL from HALT №1
npx vercel --prod
```
- Then domains:
```bash
npx vercel domains ls
npx vercel domains add peezymove.com
npx vercel domains add www.peezymove.com   # Vercel will auto-redirect www → apex; confirm redirect direction is www → apex
```
- **HALT №2 (conditional):** if Vercel reports DNS not pointing at it (the domain currently serves the old Dispatch site), print the exact DNS records Vercel asks for (A / CNAME values) and wait — Adam changes them at Namecheap. After he confirms, re-run `npx vercel domains inspect peezymove.com` until verified. DNS propagation can take up to an hour; poll every 10 minutes, max 6 polls, then report status and continue to Phase 4 (Phase 5 re-checks the domain).

## Phase 4 — Firebase cleanup (waitlist funeral + legal redirects)

- **HALT №3 — ask Adam for the local path to the Firebase project repo** (the one containing `functions/` and `firebase.json` for project `peezy-1ecrdl`). If he doesn't have it locally, print the two changes below for him to apply later and skip this phase.
1. In `functions/`, find the `joinWaitlist` export (grep for `joinWaitlist`). Remove the export and its handler. Do not touch any other function.
2. In `firebase.json`, add to the hosting config:
```json
"redirects": [
  { "source": "/privacy**", "destination": "https://peezymove.com/privacy", "type": 301 },
  { "source": "/terms**",   "destination": "https://peezymove.com/terms",   "type": 301 }
]
```
3. Deploy narrowly: `firebase deploy --only functions,hosting --project peezy-1ecrdl`. When the CLI asks to confirm deletion of `joinWaitlist`, confirm.
4. Diff discipline: show Adam the full diff of both files before deploying. Only these two changes may be in it.

## Phase 5 — Live verification (evidence, not adjectives)

Run and paste real outputs:
```bash
for p in / /about /realtors /promise /contact /disclosure /privacy /terms; do
  printf "%s %s\n" "$p" "$(curl -s -o /dev/null -w '%{http_code}' https://peezymove.com$p)"
done
curl -s https://peezymove.com/robots.txt
curl -s https://peezymove.com/sitemap.xml | grep -c "<loc>"     # expect 8
curl -s https://peezymove.com/ | grep -c "noindex"               # expect 0
curl -s https://peezymove.com/ | grep -o "FAQPage"               # expect a match
curl -s -o /dev/null -w '%{http_code} %{redirect_url}\n' <OLD_FIREBASE_PRIVACY_URL>   # expect 301 → peezymove.com/privacy (ask Adam for the old URL if unknown)
```
- Run Lighthouse against production: `npx lighthouse https://peezymove.com --preset=perf --quiet --chrome-flags="--headless"` if available; otherwise tell Adam to run PageSpeed Insights and record the scores.

## Phase 6 — Session notes + Adam's remaining checklist

Write `SESSION_NOTES.md` in the repo: what was done, evidence from Phase 5, anything skipped or halted. Commit and push it. Then print this checklist for Adam:

1. Google Search Console: verify peezymove.com, submit `https://peezymove.com/sitemap.xml`, request indexing on `/`.
2. App Store Connect: point Privacy Policy and EULA URLs at `peezymove.com/privacy` and `/terms`.
3. Replace `public/badges/app-store-badge.svg` with Apple's official badge (Apple Marketing Resources).
4. Drop in real assets per `peezy-site/README.md` table (two Rotato loops, four screenshots, founder photo, OG images) — overwrite files, push, Vercel auto-deploys.
5. Replace placeholder legal text in `app/privacy/page.tsx` and `app/terms/page.tsx` with the real policies.
6. Send the Allconnect application email (drafted, in Claude chat) — **only after** items 1–5 are done.

---

## Paste-in prompt for Claude Code (Adam: start here)

```
Read RUNBOOK.md in this folder in full, then execute it phase by phase.
The site in ./peezy-site/ is finished and verified — you are deploying, not
building. Do not modify copy, design, or dependencies. Honor every HALT:
stop and ask me. Any step failing twice: stop and report the exact error.
End by writing SESSION_NOTES.md and printing my remaining manual checklist.
```
